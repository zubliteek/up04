﻿using HelpDesk.Models;
using System;
using System.Collections.Generic;

namespace HelpDesk.Data
{
    public static class TestTicketData
    {
        public static List<Ticket> GetTickets()
        {
            return new List<Ticket>
            {
                new Ticket
                {
                    Id = 1,
                    Category = "Сеть",
                    Description = "Нет доступа в Интернет",
                    Priority = "Высокий",
                    Status = "Новая",
                    CreatedAt = DateTime.Now
                },
                new Ticket
                {
                    Id = 2,
                    Category = "ПО",
                    Description = "Не запускается Microsoft Word",
                    Priority = "Средний",
                    Status = "В работе",
                    CreatedAt = DateTime.Now
                },
                new Ticket
                {
                    Id = 3,
                    Category = "Оборудование",
                    Description = "Не работает принтер",
                    Priority = "Низкий",
                    Status = "Выполнена",
                    CreatedAt = DateTime.Now
                },
                new Ticket
                {
                    Id = 4,
                    Category = "Периферия",
                    Description = "Не работает принтер в кабинете 214",
                    Priority = "Средний",
                    Status = "Новая",
                    CreatedAt = DateTime.Now
                },
                new Ticket
                {
                    Id = 5,
                    Category = "Учётная запись",
                    Description = "Забыт пароль от учётной записи",
                    Priority = "Высокий",
                    Status = "Отклонена",
                    CreatedAt = DateTime.Now
                }
            };
        }
    }
}
